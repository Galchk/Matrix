package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // write your code here
        int a;
        int sumBefore = 0;
        int sumAfter = 0;
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите четное число !");
        a = scan.nextInt();
        if (a % 2 > 0) {
            System.out.println("Ошибка ввода!");
        } else {
            int[] arr = new int[a];
            for (int i = 0; i < a; i++) {
                arr[i] = (int) (Math.random() * 12 - 6);
                System.out.print(arr[i] + " ");
            }

            System.out.println();
            for (int i = 0; i < a / 2; i++) {
                sumBefore = sumBefore + arr[i];}
            for (int i=a/2; i<a; i++){
                sumAfter=sumAfter+arr[i];}
            System.out.print("Sum of first half"+sumBefore+"  Sum of second half="+sumAfter);

            }
        }
    }


