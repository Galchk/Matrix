package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n=15;
        int[] a = new int[n];
        int x=0;
        for (int i = 0; i <= n-1; i++) {
            a[i] = (int)(Math.random() * 11-1);
            System.out.print(a[i] + ", ");
            if ((a[i]%2)==0) x++;
        }
        System.out.println("Number of evens="+x);
    }
}
