package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int n = 20;
        int[] fib = new int[n];
        for (int i = 0; i < n; i++) {
            if (i == 0) {
                fib[i] = 1;
            }
            if (i == 1) {
                fib[i] = 1;
            }
            if (i > 1) {
                fib[i] = fib[i - 1] + fib[i - 2];
            }
            System.out.print(fib[i] + " ");
        }
    }
}
