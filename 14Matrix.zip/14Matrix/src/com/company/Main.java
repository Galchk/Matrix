package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        // write your code here
        int a;

        Scanner scan = new Scanner(System.in);
        System.out.println("Введите  число >3!");
        a = scan.nextInt();
        if (a <= 3) {
            System.out.println("Ошибка ввода!");
        } else {
            int[] arr = new int[a];
            for (int i = 0; i < a; i++) {
                arr[i] = (int) (Math.random() * (a * 2 + 1) - 1);
                System.out.print(arr[i] + " ");
            }
            System.out.println();
            int[] bEven = new int[arr.length];
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] % 2 == 0) {
                    bEven[i] = arr[i];
                    System.out.print(bEven[i] + "  ");
                }
            }
        }
    }
}

