package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int n = 5;
        int[] a = new int[n];
        int m = 5;
        int[] b = new int[m];
        int sumA=0;
        int sumB=0;
        for (int i = 0; i <= (n-1); i++) {
            a[i] = (int) (Math.random() * 5);
            System.out.print(a[i] + ", ");
        }
        for (int i = 0; i <= (n-1); i++) {
            sumA = sumA+a[i];
        }
        int aav=sumA/n;

        System.out.println();
        for (int j = 0; j <= (n-1); j++) {
            a[j] = (int) (Math.random() * 7-1);
            System.out.print(a[j] + ", ");
        }
        System.out.println();
        for (int j = 0; j <= (n-1); j++) {
            sumB = sumB+a[j];
        }
        int bav=sumB/n;

        if (aav>bav) {
            System.out.print("Average of Matrix A is bigger");
        }
        if (bav>aav){
            System.out.print("Average of Matrix B is bigger");
        }
        else {
            System.out.print("Average of MatrixA EQUALS to average of Matrix B");
        }
        }
    }



