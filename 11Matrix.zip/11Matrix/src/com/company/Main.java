package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int n = 11;
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 3 - 2);
            System.out.print(arr[i] + " ");
        }
        System.out.println();
        int zero = 0;
        int minus1 = 0;
        int plus1 = 0;
        for (int i = 0; i < n; i++) {
            if (arr[i] == 0) {
                zero = zero + 1;
            }
            if (arr[i] == -1) {
                minus1 = minus1 + 1;
            }
            if (arr[i] == 1) {
                plus1 = plus1 + 1;
            }
        }
            if (zero > minus1 && (zero) > minus1) {
                System.out.println("zero is the most often, its number =" + zero);
            }
            if (minus1 > zero && minus1 > plus1) {
                System.out.println("-1 is te most often, its number =" + minus1);
            }
            if (plus1 > zero && plus1 > minus1) {
                System.out.println("1 is the most often, its number =" + plus1);
            }

        }
    }

