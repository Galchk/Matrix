package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int n = 12;
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 31 - 16);
            System.out.print(arr[i] + " ");
        }
        int nom =0;
        int max = arr[0];
        for (int i =(n-1); i>=0; i--) {
            if (max < arr[i]) {
                max = arr[i];
                nom = i;
            }
        }
                System.out.println("\n Maximum=" + max+"Number="+ nom);
            }
        }


