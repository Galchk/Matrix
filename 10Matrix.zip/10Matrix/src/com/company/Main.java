package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n=10;
        int[]arr=new int[n];
        int[]brr=new int[n];
        float[]div=new float[n];
        for (int i=0; i<n; i++)
        {
            arr[i]=(int)(Math.random()*9+1);
            System.out.print(arr[i]+" ");
        }
        System.out.println();
        for (int i=0; i<n; i++)
        {
            brr[i] = (int)(Math.random() * 9+1);
            System.out.print(brr[i] + " ");
        }
        System.out.println();
        for (int i=0; i<n; i++)
        {
            div[i]=arr[i]/brr[i];
            System.out.print(div[i]+" ");
        }
        System.out.println();
int count=0;
        for (int i=0; i<n; i++)
        {
            if (div[i]%1==0){
                count=count+1;
            }
         }
        System.out.println("number of integers="+count);
    }
}
