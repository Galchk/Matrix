package com.company;

public class Main {

    public static void main(String[]args) {
        // write your code here
        int n;
        n=10;
        int[]a=new int[n];

        for (int i = 0; i <= (n-1); i++) {
            a[i] = (i * 2 + 2);
            System.out.print(a[i] + " ");}


        }


}
