package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int n = 4;
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = (int) (Math.random() * 91 + 9);
            //a[i] = i;
            System.out.print(a[i] + ", ");
        }
        System.out.println();
        boolean isgrowing=true;
        for (int i = 1; i < n; i++) {
            if (a[i] <= a[i - 1]) {
                isgrowing=false;
            }

        }
        if(isgrowing) System.out.println("Growing");
        else System.out.println("not");
    }
}




