package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code
        int n = 12;
        int[] a = new int[n];
        int calcNeg = 0;
        int calcPos = 0;
        int i = 0;

        while (calcNeg <= 6 && calcPos <= 6) {

            int ran = (int) (Math.random() * 22 - 11);
            if (ran != 0 && ran > 0) {
                calcPos = calcPos + 1;
                a[i] = ran;
            } else if (ran != 0 && ran < 0) {
                calcNeg = calcNeg + 1;
                a[i] = ran;


                System.out.print(a[i] + ", ");

            }
        }
    }
}





