package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n=8;
        int[] a = new int[n];
        int[] b = new int[n];
        for (int i = 0; i <= n-1; i++) {
            a[i] = (int)(Math.random() * 11);
            System.out.print(a[i] + ", ");
        }
        System.out.println();
        for (int i = 0; i <= n-1; i++) {
            if ((a[i] % 2) == 0) {
            b[i] = 0;}
            else {b[i] = a[i];}

            System.out.print(b[i] + ", ");
        }
    }
}
